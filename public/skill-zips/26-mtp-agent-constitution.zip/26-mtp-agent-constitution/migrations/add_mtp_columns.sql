-- Add MTP (Massive Transformative Purpose) columns to the org/workspace identity table.
ALTER TABLE public.brand_profiles
  ADD COLUMN IF NOT EXISTS mtp text,
  ADD COLUMN IF NOT EXISTS mtp_boundary_conditions jsonb NOT NULL DEFAULT '[]'::jsonb;

COMMENT ON COLUMN public.brand_profiles.mtp IS
  'Massive Transformative Purpose: one-sentence constitutional mandate injected into every agent system prompt.';
COMMENT ON COLUMN public.brand_profiles.mtp_boundary_conditions IS
  'Array of Never/Always rules — hard constraints agents must not violate.';
