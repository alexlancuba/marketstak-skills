import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useOptionalWorkspace } from "@/contexts/WorkspaceContext";
import { Badge } from "@/components/ui/badge";
import { Shield, ShieldAlert } from "lucide-react";

/** Small status pill: "MTP Active · N guardrails" or a prompt to set one up. */
export function MtpBadge() {
  const { user } = useAuth();
  const ws = useOptionalWorkspace();
  const activeWorkspaceId = ws?.activeWorkspaceId ?? null;
  const [state, setState] = useState<{ active: boolean; count: number } | null>(null);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      let query: any = supabase
        .from("brand_profiles")
        .select("mtp, mtp_boundary_conditions")
        .order("updated_at", { ascending: false })
        .limit(1);
      if (activeWorkspaceId) query = query.eq("workspace_id", activeWorkspaceId);
      else query = query.eq("user_id", user.id);
      const { data } = await query.maybeSingle();
      if (cancelled) return;
      const mtp = typeof data?.mtp === "string" ? data.mtp.trim() : "";
      const bc = Array.isArray(data?.mtp_boundary_conditions) ? data.mtp_boundary_conditions : [];
      setState({ active: mtp.length > 0, count: bc.length });
    })();
    return () => { cancelled = true; };
  }, [user, activeWorkspaceId]);

  if (!state) return null;

  if (!state.active) {
    return (
      <Link to="/brand-profile" className="inline-flex">
        <Badge variant="outline" className="gap-1.5 text-[10px] cursor-pointer hover:bg-secondary/60">
          <ShieldAlert size={10} className="text-muted-foreground" />
          MTP not set · configure
        </Badge>
      </Link>
    );
  }

  return (
    <Badge variant="secondary" className="gap-1.5 text-[10px]">
      <Shield size={10} className="text-primary" />
      MTP Active · {state.count} guardrail{state.count === 1 ? "" : "s"}
    </Badge>
  );
}
