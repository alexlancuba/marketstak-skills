import { useBrandProfile } from "@/contexts/BrandProfileContext";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { TagInput } from "./TagInput";
import { Badge } from "@/components/ui/badge";
import { Shield, Sparkles } from "lucide-react";
import { ConceptCard } from "@/components/ConceptCard";
import { AISuggestButton } from "@/components/AISuggestButton";

export function MtpSection() {
  const { profile, updateField } = useBrandProfile();
  const boundaryCount = (profile.mtpBoundaryConditions ?? []).length;
  const isActive = (profile.mtp ?? "").trim().length > 0;

  return (
    <section className="rounded-2xl border border-primary/20 bg-primary/[0.03] p-5 sm:p-6 space-y-5">
      <header className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
        <div className="flex items-start gap-3 min-w-0">
          <div className="rounded-lg bg-primary/10 p-2 shrink-0">
            <Sparkles size={16} className="text-primary" />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
              Massive Transformative Purpose
              {isActive && (
                <Badge variant="secondary" className="text-[10px] gap-1">
                  <Shield size={10} /> Active · {boundaryCount} guardrail{boundaryCount === 1 ? "" : "s"}
                </Badge>
              )}
            </h3>
            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
              The single, ambitious purpose your organization exists to advance — and the explicit lines agents must not cross.
            </p>
          </div>
        </div>
      </header>

      <div className="space-y-2">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <Label className="text-xs font-medium">MTP Statement</Label>
          <AISuggestButton
            field="mtp"
            fieldLabel="Massive Transformative Purpose"
            currentValue={profile.mtp ?? ""}
            onAccept={(v) => updateField("mtp", v)}
          />
        </div>
        <ConceptCard
          title="MTP"
          triggerLabel="What is an MTP?"
          definition="A bold, transformative statement of what your organization exists to do at the largest possible scale. One sentence, no hedging."
          example={
            <>
              <span className="text-foreground/80">Google:</span> "Organize the world's information." ·{" "}
              <span className="text-foreground/80">Tesla:</span> "Accelerate the world's transition to sustainable energy."
            </>
          }
          whyItMatters="Agents use your MTP as a constitutional constraint — they won't propose actions that contradict it. The clearer it is, the more aligned every output becomes."
        />
        <Textarea
          value={profile.mtp ?? ""}
          onChange={(e) => updateField("mtp", e.target.value)}
          placeholder="e.g. Make world-class marketing accessible to every founder on earth"
          rows={2}
        />
      </div>

      <div className="space-y-2">
        <Label className="text-xs font-medium">Boundary Conditions</Label>
        <ConceptCard
          title="Boundary Conditions"
          triggerLabel="What are boundary conditions?"
          definition="The specific guardrails that define the edges of your MTP — hard rules an agent must never violate."
          example='"Never produce content that misleads on pricing." · "Always disclose AI assistance in published content."'
          whyItMatters="These are injected as non-negotiable rules into every agent decision. Agents will refuse an action that crosses one and propose an alternative instead."
        />
        <p className="text-[11px] text-muted-foreground">
          Add one per line. Start each with "Never" or "Always" so it's checkable.
        </p>
        <TagInput
          tags={profile.mtpBoundaryConditions ?? []}
          onChange={(tags) => updateField("mtpBoundaryConditions", tags)}
          placeholder="e.g. Never produce content that misrepresents our pricing"
          maxTags={25}
        />
        {(profile.mtpBoundaryConditions ?? []).length === 0 && (
          <AISuggestButton
            field="mtp_boundary_condition"
            fieldLabel="MTP boundary condition"
            currentValue=""
            onAccept={(v) =>
              updateField("mtpBoundaryConditions", [...(profile.mtpBoundaryConditions ?? []), v])
            }
          />
        )}
      </div>

      <div className="rounded-lg border border-primary/20 bg-background/40 px-3 py-2.5 flex gap-2.5">
        <Shield size={14} className="text-primary shrink-0 mt-0.5" />
        <p className="text-[11px] leading-relaxed text-muted-foreground">
          <span className="text-foreground font-medium">Hard constraint, not context.</span>{" "}
          Your MTP is injected into every agent decision as a non-negotiable mandate. Agents will not propose or execute actions that fall outside these boundaries — they'll flag conflicts and propose alternatives instead.
        </p>
      </div>
    </section>
  );
}
