// Shared helper: load and format the workspace/user MTP (Massive Transformative Purpose)
// as a hard-constraint block prepended to any agent system prompt.

export interface MtpData {
  mtp: string | null;
  boundary_conditions: string[];
}

/**
 * Fetch MTP for a brand profile (by id, workspace, or user). Returns null if not set.
 * `admin` is a service-role Supabase client. Either profileId, workspaceId, or userId must be provided.
 */
export async function fetchMtp(
  admin: any,
  opts: { profileId?: string | null; workspaceId?: string | null; userId?: string | null },
): Promise<MtpData | null> {
  let row: any = null;
  try {
    if (opts.profileId) {
      const r = await admin
        .from("brand_profiles")
        .select("mtp, mtp_boundary_conditions")
        .eq("id", opts.profileId)
        .maybeSingle();
      row = r.data;
    } else if (opts.workspaceId) {
      const r = await admin
        .from("brand_profiles")
        .select("mtp, mtp_boundary_conditions")
        .eq("workspace_id", opts.workspaceId)
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      row = r.data;
    } else if (opts.userId) {
      const r = await admin
        .from("brand_profiles")
        .select("mtp, mtp_boundary_conditions")
        .eq("user_id", opts.userId)
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      row = r.data;
    }
  } catch (_) { /* swallow — MTP is optional */ }

  if (!row) return null;
  const mtp = typeof row.mtp === "string" ? row.mtp.trim() : "";
  if (!mtp) return null;
  const bc = Array.isArray(row.mtp_boundary_conditions)
    ? row.mtp_boundary_conditions.filter((s: any) => typeof s === "string" && s.trim().length > 0)
    : [];
  return { mtp, boundary_conditions: bc };
}

/** Format an MTP into a hard-constraint preamble block. Returns empty string if no MTP. */
export function formatMtpBlock(data: MtpData | null): string {
  if (!data || !data.mtp) return "";
  const conds = data.boundary_conditions.length
    ? data.boundary_conditions.map((c) => `- ${c}`).join("\n")
    : "- (none specified — use the MTP itself as the sole guardrail)";
  return `=== ORGANIZATIONAL MANDATE (MTP) ===
Massive Transformative Purpose: ${data.mtp}

Boundary Conditions (hard constraints — never violate these):
${conds}

All outputs must remain within these boundaries. If a proposed action conflicts with the MTP or any boundary condition, flag it and propose an alternative instead.
===

`;
}

/** Convenience: prepend the MTP block to a system prompt string. */
export function withMtp(systemPrompt: string, data: MtpData | null): string {
  const block = formatMtpBlock(data);
  return block ? block + systemPrompt : systemPrompt;
}
